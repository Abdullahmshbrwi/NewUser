/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import view.JFrameForm;

/**
 *
 * @author Abdullah
 */
public class InvoiceHeaderTableModel extends AbstractTableModel{
    
    private String [] header = {"No." , "Date", "Customer" , "Total"};
    private ArrayList<InvoiceHeader> invoices ;
    public InvoiceHeaderTableModel(ArrayList<InvoiceHeader> invoices) {
        this.invoices = invoices ;
    }
    

    @Override
    public int getRowCount() {
        return invoices.size();
    }
    @Override
    public int getColumnCount() {
        return header.length;
    }

    @Override
    public String getColumnName(int column) {
        return header[column];
    }
    
    
    

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        InvoiceHeader record = invoices.get(rowIndex);
        
        switch(columnIndex){
            
            case 0 : 
                    return record.getNum();
            case 1 :
                    return JFrameForm.sdf.format(record.getDate());
            case 2 :
                    return record.getName();
            case 3 : 
                    return record.getTotal();
            
        }
        return "";
    }
    
}
