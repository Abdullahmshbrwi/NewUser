/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author Abdullah
 */
public class CreateInvoiceDialog extends JDialog{
   
    private JTextField customrtNameField;
    private JTextField invoiceDateField;
    private JLabel customerNameLbl;
    private JLabel invoiceDateLbl;
    private JButton createBtn;
    private JButton cancelBtn;

    public CreateInvoiceDialog(JFrameForm frame) {
        super(frame);
        
       
        customrtNameField = new JTextField(20);  
        invoiceDateField = new JTextField(20);
        customerNameLbl = new JLabel("Customer Name:");
        invoiceDateLbl = new JLabel("Invoice Date:");
        createBtn = new JButton("Create");
        cancelBtn = new JButton("Cancel");
        
        createBtn.setActionCommand("createInvoiceCreateBtn");
        cancelBtn.setActionCommand("createInvoiceCancelBtn");
        
        createBtn.addActionListener(frame.getController());
        cancelBtn.addActionListener(frame.getController());
        setLayout(new GridLayout(3, 2));
        
        add(customerNameLbl);
        add(customrtNameField);
        add(invoiceDateLbl);
        add(invoiceDateField);
     
      
      
        
        add(createBtn);
        add(cancelBtn);
        setModal(true);
        
        pack();
        
    }

    public JTextField getCustNameField() {
        return customrtNameField;
    }

    public JTextField getInvDateField() {
        return invoiceDateField;
    }
    
}

    

